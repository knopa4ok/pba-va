import { createBrowserHistory } from "history";

export const API_URL = "https://api2.pbd-va.ru";
//export const API_URL = "http://pbdapi.local";
export const hist = createBrowserHistory();
export const languages = ["en", "ru"];
